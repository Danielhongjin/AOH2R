var players = {}; 
Object.size = function(obj) {
    var size = 0, key;
    for (key in obj) {
        if (obj.hasOwnProperty(key)) size++;
    }
    return size;
};
function AddDebugPlayer(color)
{
	var panel = $.CreatePanel('Panel', $('#Players'), '');
	panel.BLoadLayoutSnippet("Player");
	panel.FindChildTraverse('PlayerNameSignal').text = "assbutt";
	panel.FindChildTraverse('PlayerDamageDealth').text = "666"
	panel.FindChildTraverse('PlayerDamageTaken').text = "666";
	$.Msg("hello")
}  
function InitDamagePanels(data)
{
	for (const [key, index] of Object.entries(data.players)) {
		var panel = $.CreatePanel('Panel', $('#Players'), '');
		panel.BLoadLayoutSnippet("Player");
		panel.FindChildTraverse('PlayerHeroSignal').text = $.Localize(Players.GetPlayerSelectedHero(index)).toUpperCase();
		panel.FindChildTraverse('PlayerDamageDealt').text = "0"
		panel.FindChildTraverse('PlayerDamageTaken').text = "0";
		panel.FindChildTraverse('PlayerDamageHealed').text = "0";
		panel.FindChildTraverse('PlayerDPS').text = "0";
		players[index] = panel;
	}
	
	
	
}
function Delete()
{
	$("#Players").RemoveAndDeleteChildren();
}


function SetDamageDealt(damage)
{
    players[damage.id].FindChildTraverse('PlayerDamageDealt').text = damage.damage;
    players[damage.id].FindChildTraverse('PlayerDPS').text = damage.dps;
    players[damage.id].FindChildTraverse('PlayerDamageHealed').text = damage.healing;
    players[damage.id].FindChildTraverse('PlayerDamageTaken').text = damage.damage_taken;
	var total = damage.physical + damage.magical + damage.pure;
	var physpercent =  Math.floor(damage.physical / total * 100)
	var magpercent =  Math.floor(damage.magical / total * 100)
	var purepercent =  Math.floor(damage.pure / total * 100)
	if (physpercent + magpercent + purepercent < 100)
	{
		if (physpercent > magpercent && physpercent > purepercent)
			physpercent = 100 - magpercent - purepercent;
		else if (magpercent > purepercent)
			magpercent = 100 - physpercent - purepercent;
		else purepercent = 100 - physpercent - magpercent;
	}
	players[damage.id].FindChildTraverse('Playerphysdamagepercent').text = physpercent + "%";
	players[damage.id].FindChildTraverse('Playermagdamagepercent').text = magpercent + "%";
	players[damage.id].FindChildTraverse('Playerpuredamagepercent').text = purepercent + "%";
	
	players[damage.id].FindChildTraverse("PlayerPhysical").style.width = physpercent + "%";
	players[damage.id].FindChildTraverse("PlayerMagical").style.width = magpercent  + "%";
	players[damage.id].FindChildTraverse("PlayerPure").style.width = purepercent + "%";
}	

function debug()
{
	
	GameEvents.Subscribe("dps_init", InitDamagePanels);
	GameEvents.Subscribe("damage_update", SetDamageDealt);
	GameEvents.Subscribe("delete", Delete);
	$.Msg("Debug");
}

debug();