function AddDebugDifficulty(color)
{
	panel = $.CreatePanel('Panel', $('#Difficulties'), '');
	panel.BLoadLayoutSnippet("Difficulty");
	$.Msg("hello")
}  
Object.size = function(obj) {
    var size = 0, key;
    for (key in obj) {
        if (obj.hasOwnProperty(key)) size++;
    }
    return size;
};
function GetDifficulty(id)
{
	switch (id) {
		case 0:
			return 'Easy';
		break;
		case 1:
			return 'Normal';
		break;
		case 2:
			return 'Hard';
		break;
	}
	return 'N/A';
}
function AddName(name, id)
{
	$.Msg(id);
	switch (id) {
		case 0:
			$('#playerLabel0').text = $.Localize(name);
			$('#playerLabelChoice0').text = 'Normal';
		break;
		case 1:
			$('#playerLabel1').text = $.Localize(name);
			$('#playerLabelChoice1').text = 'Normal';
		break;
		case 2:
			$('#playerLabel2').text = $.Localize(name);
			$('#playerLabelChoice2').text = 'Normal';
		break;
		case 3:
			$('#playerLabel3').text = $.Localize(name);
			$('#playerLabelChoice3').text = 'Normal';
		break;
		case 4:
			$('#playerLabel4').text = $.Localize(name);
			$('#playerLabelChoice4').text = 'Normal';
		break;
	}
}
function InitDifficulty(data)
{    
    $.Msg("hello initDifficulty");
    var panel = $.CreatePanel('Panel', $('#Difficulties'), '');
    panel.BLoadLayoutSnippet("Difficulty");
    $('#Normal').AddClass("Selected")
    $('#Easy').SetPanelEvent('onactivate', () => {
        GameEvents.SendCustomGameEventToServer('difficulty_clicked', {
			type: 0,
            id: Players.GetLocalPlayer(),
            choice: 0,
        });
        $('#Easy').AddClass("Selected");
        $('#Normal').RemoveClass("Selected");
        $('#Hard').RemoveClass("Selected");
    });
    $('#Normal').SetPanelEvent('onactivate', () => {
        GameEvents.SendCustomGameEventToServer('difficulty_clicked', {
			type: 0,
            id: Players.GetLocalPlayer(),
            choice: 1,
        });
        $('#Easy').RemoveClass("Selected");
        $('#Normal').AddClass("Selected");
        $('#Hard').RemoveClass("Selected");
    });
    $('#Hard').SetPanelEvent('onactivate', () => {
        GameEvents.SendCustomGameEventToServer('difficulty_clicked', {
			type: 0,
            id: Players.GetLocalPlayer(),
            choice: 2,
        });
        $('#Easy').RemoveClass("Selected");
        $('#Normal').RemoveClass("Selected");
        $('#Hard').AddClass("Selected");
    });
	$('#Laser').SetPanelEvent('onactivate', () => {
        GameEvents.SendCustomGameEventToServer('difficulty_clicked', {
			type: 1,
            id: Players.GetLocalPlayer(),
            choice: 0,
        });
    });
    $('#Nightmare').SetPanelEvent('onactivate', () => {
        GameEvents.SendCustomGameEventToServer('difficulty_clicked', {
			type: 1,
            id: Players.GetLocalPlayer(),
            choice: 1,
        });
    });
    $('#Double').SetPanelEvent('onactivate', () => {
        GameEvents.SendCustomGameEventToServer('difficulty_clicked', {
			type: 1,
            id: Players.GetLocalPlayer(),
            choice: 2,
        });
    });
	$('#SuddenDeath').SetPanelEvent('onactivate', () => {
        GameEvents.SendCustomGameEventToServer('difficulty_clicked', {
			type: 1,
            id: Players.GetLocalPlayer(),
            choice: 3,
        });
    });
	var players = data.players;
	for (const [key, index] of Object.entries(players)) {
		AddName(Players.GetPlayerSelectedHero(index), index);
	}
}

function Delete()
{
	$('#Difficulties').RemoveAndDeleteChildren();
}
function Update(data)
{
	if (data.update_type == 0) {	
		var str = "#playerLabelChoice";
		str += data.id;
		$(str).text = GetDifficulty(data.difficulty);
	} else {
		var str = "#player";
		str += data.id;
		switch (data.choice) {
			case 0: {
				$(str).FindChild("LaserChoice").ToggleClass("Hidden");
				break;
			}
			case 1: {
				$(str).FindChild("NightmareChoice").ToggleClass("Hidden");
				break;
			}
			case 2: {
				$(str).FindChild("DoubleChoice").ToggleClass("Hidden");
				break;
			}
			case 3: {
				$(str).FindChild("SuddenDeathChoice").ToggleClass("Hidden");
				break;
			}
		}
		$.Msg(data.choice);
		if (data.id == Players.GetLocalPlayer()) {
			if (data.value == 1 ) {
				switch(data.choice) {
					case 0: {
						$('#Laser').AddClass("Selected");
						break;
					}
					case 1: {
						$('#Nightmare').AddClass("Selected");
						break;
					}
					case 2: {
						$('#Double').AddClass("Selected");
						break;
					}
					case 3: {
						$('#SuddenDeath').AddClass("Selected");
						break;
					}
				}
			} else {
				switch(data.choice) {
					case 0: {
						$('#Laser').RemoveClass("Selected");
						break;
					}
					case 1: {
						$('#Nightmare').RemoveClass("Selected");
						break;
					}
					case 2: {
						$('#Double').RemoveClass("Selected");
						break;
					}
					case 3: {
						$('#SuddenDeath').RemoveClass("Selected");
						break;
					}
				}
			}
		}
		
	}

}
function debug()
{
    GameEvents.Subscribe("game_begin", InitDifficulty);
    GameEvents.Subscribe("vote_end", Delete);
	GameEvents.Subscribe("vote_update", Update);
	$.Msg("Debug");
}

debug();