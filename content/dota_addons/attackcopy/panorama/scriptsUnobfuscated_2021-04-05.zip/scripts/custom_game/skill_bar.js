var player_id = 0
var open = false;

var TIER_1_SKILLS = ["modifier_skill_dashcooldown", "modifier_skill_equalizer", "modifier_skill_dashimmunity", "modifier_skill_flashcaster"];
var TIER_2_SKILLS = ["modifier_skill_minitalon", "modifier_skill_lightbones", "modifier_skill_atronach", "modifier_skill_overtuned"];
var TIER_3_SKILLS = ["modifier_skill_trident", "modifier_skill_transfusion", "modifier_skill_dashdamage", "modifier_skill_flames"];
var TIER_4_SKILLS = ["modifier_skill_noevil", "modifier_skill_jack", "modifier_skill_cardio", "modifier_skill_bloodmana"];
var TIER_5_SKILLS = ["modifier_skill_midas", "modifier_skill_license", "modifier_skill_luck", "modifier_skill_wavedash"];

function InitSkills(data)
{
	player_id = data.id;
	$("#CurrencyValueLabel").text = data.value;
	for (var i = 0; i < 4; i++) {
		var skill = $.CreatePanel('Panel', $('#Tier1'), '');
		skill.BLoadLayoutSnippet("SkillBox");
		skill.SetDialogVariable("skill_name", $.Localize(TIER_1_SKILLS[i]));
		skill.FindChildTraverse("SkillIcon").SetImage('file://{images}/custom_game/icons/' + TIER_1_SKILLS[i] + '.png');
		skill.SetDialogVariable("tooltip", $.Localize("#" + TIER_1_SKILLS[i] + "_Description"));
		skill.AddClass("" + i);
		InitBox(skill, i, 1);
    }
	for (var i = 0; i < 4; i++) {
		var skill = $.CreatePanel('Panel', $('#Tier2'), '');
		skill.BLoadLayoutSnippet("SkillBox");
		skill.SetDialogVariable("skill_name", $.Localize(TIER_2_SKILLS[i]));
		skill.FindChildTraverse("SkillIcon").SetImage('file://{images}/custom_game/icons/' + TIER_2_SKILLS[i] + '.png');
		skill.SetDialogVariable("tooltip", $.Localize("#" + TIER_2_SKILLS[i] + "_Description"));
		skill.AddClass("" + i);
		InitBox(skill, i, 2);
    }
	for (var i = 0; i < 4; i++) {
		var skill = $.CreatePanel('Panel', $('#Tier3'), '');
		skill.BLoadLayoutSnippet("SkillBox");
		skill.SetDialogVariable("skill_name", $.Localize(TIER_3_SKILLS[i]));
		skill.FindChildTraverse("SkillIcon").SetImage('file://{images}/custom_game/icons/' + TIER_3_SKILLS[i] + '.png');
		skill.SetDialogVariable("tooltip", $.Localize("#" + TIER_3_SKILLS[i] + "_Description"));
		skill.AddClass("" + i);
		InitBox(skill, i, 3);
    }
	for (var i = 0; i < 4; i++) {
		var skill = $.CreatePanel('Panel', $('#Tier4'), '');
		skill.BLoadLayoutSnippet("SkillBox");
		skill.SetDialogVariable("skill_name", $.Localize(TIER_4_SKILLS[i]));
		skill.FindChildTraverse("SkillIcon").SetImage('file://{images}/custom_game/icons/' + TIER_4_SKILLS[i] + '.png');
		skill.SetDialogVariable("tooltip", $.Localize("#" + TIER_4_SKILLS[i] + "_Description"));
		skill.AddClass("" + i);
		InitBox(skill, i, 4);
    }
	for (var i = 0; i < 4; i++) {
		var skill = $.CreatePanel('Panel', $('#Tier5'), '');
		skill.BLoadLayoutSnippet("SkillBox");
		skill.SetDialogVariable("skill_name", $.Localize(TIER_5_SKILLS[i]));
		skill.FindChildTraverse("SkillIcon").SetImage('file://{images}/custom_game/icons/' + TIER_5_SKILLS[i] + '.png');
		skill.SetDialogVariable("tooltip", $.Localize("#" + TIER_5_SKILLS[i] + "_Description"));
		skill.AddClass("" + i);
		InitBox(skill, i, 5);
    }
	$("#CurrentCurrency").text = data.currency;
}
function InitBox(skill, i, tier)
{
	skill.SetPanelEvent('onactivate', () => {
		GameEvents.SendCustomGameEventToServer('skill_selected', {
				tier: tier,
				id: player_id,
				choice: i,
			});
		if (!skill.BHasClass("inactive")) {
			var name = '#Tier' + tier;
			var panels = $(name).FindChildrenWithClassTraverse("SkillBox");
			for (count = 0; count < panels.length; count++) {
				panels[count].RemoveClass("active");		
			}
			$("#SkillBar").RemoveClass("skillbaractive");
			$("#skill_bar_button").RemoveClass("skillbarbuttonactive")
		}
	});
}

function PurchaseSkill(data) {
	$("#CurrentCurrency").text = data.currency;
	var string = "#Tier" + data.tier;
	var panels = $(string).FindChildrenWithClassTraverse("" + data.choice);
	if (data.transaction == 1) {
		for (i = 0; i < panels.length; i++) {
			panels[i].AddClass("selected");	
			panels[i].RemoveClass("notselected");	
		}
	} else {
		for (i = 0; i < panels.length; i++) {
			panels[i].AddClass("notselected");	
			panels[i].RemoveClass("selected");	
		}
	}
}

function UpdateCurrency(data) {
	$("#CurrentCurrency").text = data.currency;
	$("#skill_bar_button").RemoveClass("CurrencyAnimation");
	$("#skill_bar_button").AddClass("CurrencyAnimation");
}

function UpdateValue(data) {
	$("#CurrencyValueLabel").text = data.value;
}
function buy() {
	GameEvents.SendCustomGameEventToServer('credit_transaction', {
		type: 0,
		id: Players.GetLocalPlayer(),
	});
}

function sell() {
	GameEvents.SendCustomGameEventToServer('credit_transaction', {
		type: 1,
		id: Players.GetLocalPlayer(),
	});
}

function on_skill_bar_button_click() {
    find_hud_element("skill_bar_button").GetParent().style.transform = (open ? "translateX(1000px)" : "translateX(0)");
    open = !open;
}

function UnlockSkills(data)
{
	$.Msg(data.tier);
	$("#SkillBar").AddClass("skillbaractive");
	$("#skill_bar_button").AddClass("skillbarbuttonactive");
	if (!open) {
		on_skill_bar_button_click();
	}
	var string = "#Tier" + data.tier;
	var panels = $(string).FindChildrenWithClassTraverse("inactive");
	for (i = 0; i < panels.length; i++) {
		panels[i].RemoveClass("inactive");	
		panels[i].AddClass("active");				
	}
}
function Delete()
{
	$("#Tier1").RemoveAndDeleteChildren();
	$("#Tier2").RemoveAndDeleteChildren();
	$("#Tier3").RemoveAndDeleteChildren();
	$("#Tier4").RemoveAndDeleteChildren();
	$("#Tier5").RemoveAndDeleteChildren();
}

function init()
{ 
	GameEvents.Subscribe("skill_bar_init", InitSkills);
	GameEvents.Subscribe("skill_bar_unlock", UnlockSkills);
	GameEvents.Subscribe("skill_purchase_success", PurchaseSkill);
	GameEvents.Subscribe("update_currency", UpdateCurrency);
	GameEvents.Subscribe("update_value", UpdateValue);
	GameEvents.Subscribe("delete", Delete);
	$("#CurrentCurrency").text = 0;
	$.Msg("SkillBarInit");
}



init();