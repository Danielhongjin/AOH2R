var open = false;
var dash_slider;
var active_dash = 0;
var dash_count = 0;
var hpbars = new Map();

function AddHealthBar(data)
{
	var panel = $.CreatePanel('Panel', $('#boss_healthbar_box'), '');
	panel.BLoadLayoutSnippet("boss_healthbar");
	panel.FindChildTraverse('boss_name').text = $.Localize(data.name);
	hpbars.set(Math.floor(data.index), panel);
}  

function UpdateHealthBar(data)
{
	var temp = hpbars.get(Math.floor(data.index)).FindChildTraverse('boss_hp');
	temp.style.width = data.health + "%";
	temp.value = data.health;
	hpbars.get(Math.floor(data.index)).FindChildTraverse('boss_mana').style.width = data.mana + "%";
}  

function UpdateStateBar(data)
{
	var temp = hpbars.get(Math.floor(data.index))
	value = Math.abs(100 - temp.FindChildTraverse("boss_hp").value);
	temp.FindChildTraverse('damage_track').style.transform = "translateX(-" + 600 * value * 0.01 + "px)";
}  

function RemoveHealthBar(data)
{
	hpbars.get(Math.floor(data.index)).RemoveAndDeleteChildren()
	hpbars.delete(Math.floor(data.index));
	if (hpbars.size < 1) {
		$("#boss_healthbar_box").RemoveAndDeleteChildren()
	}
}  

function on_options_button_click() {
    find_hud_element("options_button").GetParent().style.transform = (open ? "translateX(350px)" : "translateX(0)");
    open = !open;
}

function submit_settings() {
	GameEvents.SendCustomGameEventToServer('settings_update', {
		id: Players.GetLocalPlayer(),
		dash_value: parseFloat(dash_slider.value.toFixed(2)),
	});
}

function credits_clicked() {
	$("#credits_button").AddClass("inactive");
	GameEvents.SendCustomGameEventToServer('credits_clicked', {
		id: Players.GetLocalPlayer(),
	});
}

function init() {
    dash_slider = $("#dash_slider");
	dash_slider.value = 0.22;
	
	GameUI.SetMouseCallback( function( eventName, arg ) {
		var CONSUME_EVENT = true;
		var CONTINUE_PROCESSING_EVENT = false;

		if (GameUI.GetClickBehaviors() !== CLICK_BEHAVIORS.DOTA_CLICK_BEHAVIOR_NONE)
			return CONTINUE_PROCESSING_EVENT;
		dash_count++;
		$.Schedule(dash_slider.value, function() {
			if (dash_count > 0) {
				dash_count--;
			}
		})
		if (eventName == "pressed")
		{
			// Left-click is move to position
			if (arg === 1 && dash_count > 1)
			{
				GameEvents.SendCustomGameEventToServer('dash', {
					id: Players.GetLocalPlayer(),
					pos: GameUI.GetScreenWorldPosition(GameUI.GetCursorPosition()),
					units: Players.GetSelectedEntities(Players.GetLocalPlayer()),
				});
			}
		}
		return CONTINUE_PROCESSING_EVENT;
	} );
	GameEvents.Subscribe("healthbar_init", AddHealthBar);
	GameEvents.Subscribe("healthbar_update", UpdateHealthBar);
	GameEvents.Subscribe("healthbar_delete", RemoveHealthBar);
	GameEvents.Subscribe("statebar_update", UpdateStateBar);
}
init();
